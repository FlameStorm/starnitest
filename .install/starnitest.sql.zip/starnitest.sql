-- phpMyAdmin SQL Dump
-- https://www.phpmyadmin.net/
--

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `starnitest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE `blocks` (
  `number` bigint(20) NOT NULL,
  `hash` char(67) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ts` datetime NOT NULL,
  `tx_count` bigint(20) NOT NULL DEFAULT 0,
  `gas_used` bigint(20) NOT NULL,
  `gas_limit` bigint(20) NOT NULL,
  `json_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `hash` char(67) COLLATE utf8mb4_unicode_ci NOT NULL,
  `block_hash` char(67) COLLATE utf8mb4_unicode_ci NOT NULL,
  `block_number` bigint(20) NOT NULL,
  `transaction_index` int(11) NOT NULL,
  `gas_price` double NOT NULL,
  `gas` double NOT NULL,
  `value` double NOT NULL,
  `json_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`hash`) USING BTREE,
  ADD KEY `create_dt` (`create_dt`);

--
-- Индексы таблицы `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`hash`),
  ADD KEY `create_dt` (`create_dt`) USING BTREE,
  ADD KEY `block_hash` (`block_hash`) USING BTREE,
  ADD KEY `block_number` (`block_number`) USING BTREE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
